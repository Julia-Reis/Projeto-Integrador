<?php
	setcookie("id_usuario", "");
	setcookie("nome_usuario","");
	setcookie("senha_usuario","");
	setcookie("nome","");
?>