<?php
	$p = null;
	$p["titulo"] = $titulo;
	$p["id_titulo"] = $id;   
?>