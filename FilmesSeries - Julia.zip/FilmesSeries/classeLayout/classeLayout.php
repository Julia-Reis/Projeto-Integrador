<?php

    include "classeCabecalho.php";
    include "classeFooter.php";
    include "classeTabela.php";
    include "classeModal.php";
	include "classeRodape.php";

?>