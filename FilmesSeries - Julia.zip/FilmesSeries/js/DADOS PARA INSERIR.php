FILMES - LANCAMENTOS
Mulher-Maravilha 1984

Wonder Woman 1984 é um futuro filme estadunidense de super-herói de 2020, 
baseado na personagem homônima da DC Comics e distribuído pela Warner Bros. 
Pictures. Será a sequência de Wonder Woman de 2017, e o nono filme do Universo Estendido da DC.
Fantasia 16
24/12/2020

Os Novos Mutantes

Cinco jovens mutantes (Maisie Williams, Blu Hunt, Anya Taylor-Joy, Charlie Heaton e Henry Zaga)
descobrem o alcance de seus poderes e lidam com traumas do passado. No entanto,
eles são mantidos presos contra a vontade em uma instituição controlada pela Dr. Cecilia Reyes
(Alice Braga). Enquanto a médica promete controlar as habilidades do grupo, nada é o que parece. 
Terror 16
22/10/2020

2
Após uma morte na família, um irmão e uma irmã, que nunca haviam se conhecido,
passam a conviver um com o outro, despertando dúvidas sobre seu passado que podem
levá-los a verdades inesperadas.
Drama 14
29/10/2020

Fúria Incontrolável
Uma briga no trânsito inicia um jogo de gato e rato, colocando a vida de Rachel
(Caren Pistorius) e a de sua família em risco.
Ação 18
12/05/2020

SÉRIES - LANCAMENTOS
Hawkeye

05/01/2021

WandaVision

What If…?