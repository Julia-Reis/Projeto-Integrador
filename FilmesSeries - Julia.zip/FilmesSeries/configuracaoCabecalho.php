<?php
$p["logo"] = "img/logo.png";
$p["alt_logo"] = "Logotipo Assistiu? Comentou!";
    $p["links"][0]["link"] = "index.php";
    $p["links"][0]["label"] = "Home";
    $p["links"][1]["link"] = "lancamentos.php";
    $p["links"][1]["label"] = "Lançamentos";
	$p["links"][2]["link"] = "filmes.php";
    $p["links"][2]["label"] = "Filmes";
	$p["links"][3]["link"] = "series.php";
    $p["links"][3]["label"] = "Séries"; 
	$p["links"][4]["link"] = "avaliarFilme.php";
    $p["links"][4]["label"] = "Avaliar Filme";
	$p["links"][5]["link"] = "avaliarSerie.php";
    $p["links"][5]["label"] = "Avaliar Serie";
?>